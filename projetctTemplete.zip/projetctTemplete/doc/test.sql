/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50550
Source Host           : localhost:3306
Source Database       : test

Target Server Type    : MYSQL
Target Server Version : 50550
File Encoding         : 65001

Date: 2017-08-09 17:10:02
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for permission
-- ----------------------------
DROP TABLE IF EXISTS `permission`;
CREATE TABLE `permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `roleId` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of permission
-- ----------------------------
INSERT INTO `permission` VALUES ('1', '1', 'query');
INSERT INTO `permission` VALUES ('2', '1', 'add');
INSERT INTO `permission` VALUES ('3', '1', 'delete');
INSERT INTO `permission` VALUES ('4', '1', 'update');
INSERT INTO `permission` VALUES ('5', '2', 'query');

-- ----------------------------
-- Table structure for role
-- ----------------------------
DROP TABLE IF EXISTS `role`;
CREATE TABLE `role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of role
-- ----------------------------
INSERT INTO `role` VALUES ('1', 'admin');
INSERT INTO `role` VALUES ('2', 'normal');

-- ----------------------------
-- Table structure for tb_pr_apply_info
-- ----------------------------
DROP TABLE IF EXISTS `tb_pr_apply_info`;
CREATE TABLE `tb_pr_apply_info` (
  `APPLY_ID` varchar(36) NOT NULL,
  `EMERGENCY` varchar(15) NOT NULL,
  `EXPIRE_DATE` date NOT NULL,
  `PROCESS_UNIT` varchar(15) NOT NULL,
  `CRAFT_MODEL` varchar(7) NOT NULL,
  `REMARK` varchar(1000) DEFAULT NULL,
  `CREATE_USER` varchar(9) NOT NULL,
  `CREATE_TIME` date NOT NULL,
  `PROCESS_USER` varchar(9) DEFAULT NULL,
  `P_RNO` varchar(9) DEFAULT NULL,
  `APLLY_FILE_ID` varchar(32) DEFAULT NULL,
  `AUDIT_FILE_ID` varchar(32) DEFAULT NULL,
  `STATE` varchar(15) NOT NULL,
  `UPDATE_TIME` date NOT NULL,
  `PROCESS_INSTANCE_ID` varchar(64) NOT NULL,
  `LOG_ID` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_pr_apply_info
-- ----------------------------

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', 'test', 'test');
INSERT INTO `user` VALUES ('2', 'tt', 'tt');
INSERT INTO `user` VALUES ('3', '33', '33');

-- ----------------------------
-- Table structure for user_role
-- ----------------------------
DROP TABLE IF EXISTS `user_role`;
CREATE TABLE `user_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `roleId` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user_role
-- ----------------------------
INSERT INTO `user_role` VALUES ('1', '1', '1');
INSERT INTO `user_role` VALUES ('2', '2', '2');
INSERT INTO `user_role` VALUES ('3', '3', '2');
