package com.hq.service.jar;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ServiceProvider implements Runnable{

	@Override
	public void run() {
		@SuppressWarnings("resource")
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
				new String[] { "spring/service-applicationContext.xml" });
		context.start();
	}

	public static void main(String[] args) throws Exception {
		ServiceProvider p = new ServiceProvider();
		Thread t1 = new Thread(p);
		t1.start();
		// 为保证服务一直开着
		while (true) {
			Thread.sleep(3600000);
		}
	}

}
