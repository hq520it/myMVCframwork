package com.hq.service.test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hq.common.user.IUserService;


@Service("testService")
public class TestServiceImpl implements ITestService{

	@Autowired
	IUserService userService;
	
	@Override
	public void testHello() {
		// TODO Auto-generated method stub
		System.out.println(userService.getUserList());
		userService.sayHello("我是service模块的testHello方法！");
	}

}
