package com.hq.service.test;

public interface ITestService {

	public void testHello();
}
