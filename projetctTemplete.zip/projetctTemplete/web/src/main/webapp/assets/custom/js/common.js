var AmmsCommonTipsView = function() {

	AmmsCommonTipsView.tipsViewFunc = function(target) {
		var tipsType = arguments[1] || "";
		var top = arguments[2] || "50%";
		var rowNum = arguments[3] || 3;
		var headerHeight = $('.datagrid-header-row').height();
		var opts = $(target).datagrid('options');
		var vc = $(target).datagrid('getPanel').children('div.datagrid-view');
		vc.children('div.datagrid-empty').remove();
		var dataRows = $(target).datagrid('getRows');
		if (tipsType != "" || !dataRows.length) {
			var msg;
			if (tipsType != "") {
				for (i in opts) {
					if (i == (tipsType + "Tips")) {
						msg = opts[i];
					}
				}
			} else {
				msg = opts.emptyTips;
			}
			var d = $('<div class="datagrid-empty"></div>').html(msg).appendTo(
				vc);
			d.css({
				position : 'absolute',
				left : 0,
				top : top,
				width : '100%',
				textAlign : 'center'
			});
			$(target).datagrid('resize', {
				height : headerHeight * rowNum,
				scrollbarSize : 0
			});
			$(target).closest('div.datagrid-wrap').find('div.datagrid-pager')
			.hide();
			if (dataRows) {
				for (var i = dataRows.length - 1; i >= 0; --i) {
					var index = $(target).datagrid('getRowIndex', dataRows[i]);
					$(target).datagrid('deleteRow', index);
				}
			}
		} else {
			$(target).datagrid('resize', {
				height : 'auto',
				scrollbarSize : 0
			});
			$(target).closest('div.datagrid-wrap').find('div.datagrid-pager')
			.show();
		}
	}

	this.tipsView = $.extend({}, $.fn.datagrid.defaults.view, {
		onAfterRender : function(target) {
			$.fn.datagrid.defaults.view.onAfterRender.call(this, target);
			AmmsCommonTipsView.tipsViewFunc(target);
		}
	});
}

function AmmsCommonDatepicker() {
}

AmmsCommonDatepicker.datepicker = function(parentId) {
	var param = arguments[1] || {
		autoclose : true,
		language : "cn",
		format : "yyyy-mm-dd"
	};
	var selector = "#" + parentId + " .input-daterange";
	$(selector).datepicker(param);
}

function AmmsCommonIsDate(dateStr) {
	// 10位长度
	if (dateStr.length != 10) {
		return false;
	}
	// YYYY-MM-DD的数字形式
	var reg = /^(\d{4})-(\d{2})-(\d{2})$/;
	var r = dateStr.match(reg);
	if (r == null) {
		return false;
	}
	r[2] = r[2] - 1;
	// 判断日期是否合法，通过字符串与转换后的日期进行对比
	var d = new Date(r[1], r[2], r[3]);
	if (d.getFullYear() != r[1]) {
		return false;
	}
	if (d.getMonth() != r[2]) {
		return false;
	}
	if (d.getDate() != r[3]) {
		return false;
	}
	return true;
}

$.extend($.fn.validatebox.defaults.rules, {
	acgvLength : {
		validator: function(value, param) {
			var tempValue = value.replace(/[^\x00-\xff]/g, "**");
			return (tempValue.length >= param[0] && tempValue.length <= param[1]);
		},
		message: '长度范围应在 {0}至{1}之间'
	},
	acgvIsDate : {
		validator: function(value, param) {
			return AmmsCommonIsDate(value);
		},
		message: '请选择正确的日期'
	},
	acgvDateScope : {
		validator: function(value, param) {
			var d = new Date(value);
			var d1 = new Date(param[0]);
			var d2 = new Date(param[1]);
			if(d < d1 || d > d2) {
				return false;
			}
			return true;
		},
		message: '日期范围应在{0}至{1}之间'
	},
	acgvDateOrder : {
		validator: function(value, param) {
			var selector = param[0] + " .textbox-text.validatebox-text";
			var firstDt = $($(selector)[param[1]]).val();
			var secondDt = $($(selector)[param[2]]).val();
			if(firstDt != "" && secondDt != "") {
				if(firstDt > secondDt) {
					return false;
				}
			}
			return true;
		},
		message: '{3}日期不能早于{4}日期'
	},
	acgvIsYesOrNo : {
		validator: function(value, param) {
			return (value == "是" || value == "否");
		},
		message: '请选择正确的选项'
	},
	acgvNumberOrder : {
		validator: function(value, param) {
			var selector = param[0] + " .textbox-text.validatebox-text";
			var firstNumber = $($(selector)[param[1]]).val();
			var secondNumber = $($(selector)[param[2]]).val();
			if(firstNumber != "" && secondNumber != "") {
				if(parseFloat(firstNumber) > parseFloat(secondNumber)) {
					return false;
				}
			}
			return true;
		},
		message: '{3}不能大于{4}'
	}
});

function AmmsCommonMap() {
	this.elements = new Array();

	this.size = function() {
		return this.elements.length;
	}

	this.isEmpty = function() {
		return (this.elements.length < 1);
	}

	this.clear = function() {
		this.elements = new Array();
	}

	this.put = function(_key, _value) {
		this.elements.push({
			key : _key,
			value : _value
		});
	}

	this.remove = function(_key) {
		var bln = false;
		try {
			for (i = 0; i < this.elements.length; i++) {
				if (this.elements[i].key == _key) {
					this.elements.splice(i, 1);
					return true;
				}
			}
		} catch (e) {
			bln = false;
		}
		return bln;
	}

	this.get = function(_key) {
		try {
			for (i = 0; i < this.elements.length; i++) {
				if (this.elements[i].key == _key) {
					return this.elements[i].value;
				}
			}
		} catch (e) {
			return null;
		}
	}

	this.element = function(_index) {
		if (_index < 0 || _index >= this.elements.length) {
			return null;
		}
		return this.elements[_index];
	}

	this.containsKey = function(_key) {
		var bln = false;
		try {
			for (i = 0; i < this.elements.length; i++) {
				if (this.elements[i].key == _key) {
					bln = true;
				}
			}
		} catch (e) {
			bln = false;
		}
		return bln;
	}

	this.containsValue = function(_value) {
		var bln = false;
		try {
			for (i = 0; i < this.elements.length; i++) {
				if (this.elements[i].value == _value) {
					bln = true;
				}
			}
		} catch (e) {
			bln = false;
		}
		return bln;
	}

	this.values = function() {
		var arr = new Array();
		for (i = 0; i < this.elements.length; i++) {
			arr.push(this.elements[i].value);
		}
		return arr;
	}

	this.keys = function() {
		var arr = new Array();
		for (i = 0; i < this.elements.length; i++) {
			arr.push(this.elements[i].key);
		}
		return arr;
	}
}

var ammsCommonCloneObj = function(obj) {
	var str, newobj = obj.constructor === Array ? [] : {};
	if (typeof obj !== 'object') {
		return;
	} else if (window.JSON) {
		str = JSON.stringify(obj);
		newobj = JSON.parse(str);
	} else {
		for ( var i in obj) {
			newobj[i] = typeof obj[i] === 'object' ? cloneObj(obj[i]) : obj[i];
		}
	}
	return newobj;
};

var ammsCommonFormatter = function(date) {
	var y = date.getFullYear();
	var m = date.getMonth() + 1;
	var d = date.getDate();
	return y + '-' + (m < 10 ? ('0' + m) : m) + '-' + (d < 10 ? ('0' + d) : d);
}

var ammsCommonParser = function(s) {
	if (!s) {
		return new Date();
	}
	var ss = (s.split('-'));
	var y = parseInt(ss[0], 10);
	var m = parseInt(ss[1], 10);
	var d = parseInt(ss[2], 10);
	if (!isNaN(y) && !isNaN(m) && !isNaN(d)) {
		return new Date(y, m - 1, d);
	} else {
		return new Date();
	}
}

Date.prototype.format = function(format) {
	/*
	 * eg:format="YYYY-MM-dd hh:mm:ss";
	 */
	 var o = {
		"M+" : this.getMonth() + 1, // month
		"d+" : this.getDate(), // day
		"h+" : this.getHours(), // hour
		"m+" : this.getMinutes(), // minute
		"s+" : this.getSeconds(), // second
		"q+" : Math.floor((this.getMonth() + 3) / 3), // quarter
		"S" : this.getMilliseconds() // millisecond
	}
	if (/(y+)/.test(format)) {
		format = format.replace(RegExp.$1, (this.getFullYear() + "")
			.substr(4 - RegExp.$1.length));
	}
	for ( var k in o) {
		if (new RegExp("(" + k + ")").test(format)) {
			format = format.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k]
				: ("00" + o[k]).substr(("" + o[k]).length));
		}
	}
	return format;
}

function getByteLen(val) {
	return val.replace(/[\u4e00-\u9fa5]/g, 'xx').length;
}

var ammsZIndexBackdrop = 1030;
var ammsZIndexModal = 1040;

$(document).on('shown.bs.modal', '.modal.in', function(event) {
	ammsShownUpdateZIndex(this);
}).on('hidden.bs.modal', '.modal', function(event) {
	ammsZIndexModal -= 10;
	ammsZIndexBackdrop -= 10;
});

function ammsShownUpdateZIndex(modal) {
	ammsZIndexModal += 10;
	ammsZIndexBackdrop += 10;
	$(modal).css('z-index', ammsZIndexModal);
	var $backdrop = $(modal).data('bs.modal').$backdrop;
	$backdrop.css('z-index', ammsZIndexBackdrop);
}