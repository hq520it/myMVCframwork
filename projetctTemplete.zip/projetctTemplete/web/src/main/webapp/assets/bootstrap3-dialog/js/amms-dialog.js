function AmmsDialog() {
}

AmmsDialog.alert = function(message) {
	return new BootstrapDialog({
		title : '提示',
		message : message,
		type : BootstrapDialog.TYPE_DEFAULT,
		buttons : [ {
			label : '确定',
			cssClass : 'btn-primary',
			action : function(dialog) {
				dialog.close();
			}
		} ]
	}).open();
};

AmmsDialog.confirm = function(message, sureFunc, cancelFunc) {
	return new BootstrapDialog({
		title : '确认',
		message : message,
		type : BootstrapDialog.TYPE_DEFAULT,
		closable : true,
		closeByBackdrop : false,
		closeByKeyboard : false,
		buttons : [ {
			label : '确定',
			cssClass : 'btn-primary',
			action : function(dialog) {
				if(sureFunc != null) {
					ammsEval(sureFunc);
				}
				dialog.close();
			}
		}, {
			label : '取消',
			action : function(dialog) {
				if(cancelFunc != null) {
					ammsEval(cancelFunc);
				}
				dialog.close();
			}
		} ]
	}).open();
};

function ammsEval(fn) {
    var Fn = Function;
    return new Fn('return ' + fn)();
}