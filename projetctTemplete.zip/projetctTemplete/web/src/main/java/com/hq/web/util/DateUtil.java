package com.hq.web.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class DateUtil {
 	
 	private static final String datePattern = "yyyy-MM-dd";
	private static final String datetimePattern = "yyyy-MM-dd HH:mm:ss";
    
 	// 锁对象 用于多线程同步
 	private static final Object lockObj = new Object();
 	
 	// 存放不同的日期格式的sdf
    private static Map<String, ThreadLocal<SimpleDateFormat>> sdfMap = new HashMap<String, ThreadLocal<SimpleDateFormat>>();
 	
    /**
     * 	返回一个ThreadLocal的sdf, 每个线程只会new一次sdf
     * @param pattern
     * @return
     */
    private static SimpleDateFormat getSdf(final String pattern) {
        ThreadLocal<SimpleDateFormat> tl = sdfMap.get(pattern);
        // 此处的双重判断和同步是为了防止sdfMap这个单例被多次put重复的sdf
        if (tl == null) {
            synchronized (lockObj) {
                tl = sdfMap.get(pattern);
                if (tl == null) {
                    // 这里是关键,使用ThreadLocal<SimpleDateFormat>替代原来直接new SimpleDateFormat
                    tl = new ThreadLocal<SimpleDateFormat>() {

                        @Override
                        protected SimpleDateFormat initialValue() {
                            return new SimpleDateFormat(pattern);
                        }
                    };
                    sdfMap.put(pattern, tl);
                }
            }
        }
        return tl.get();
    }
 	
    public static String getPrevMonthLastDay() {
        //获取前月的最后一天
        Calendar lastCal = Calendar.getInstance();
        // 1
        lastCal.add(Calendar.MONTH, -1);
        lastCal.set(Calendar.DAY_OF_MONTH, lastCal.getActualMaximum(Calendar.DAY_OF_MONTH)); 
        // 2
        //cale.add(Calendar.MONTH, 1);
        //cale.set(Calendar.DAY_OF_MONTH, 0);       //设置为1号,当前日期既为本月第一天 
        
        lastCal.set(Calendar.SECOND, 59);          // 秒清零
        lastCal.set(Calendar.MINUTE, 59);          // 分清零
        lastCal.set(Calendar.HOUR_OF_DAY, 23);     // 时清零
        
        return DateUtil.getSdf(datetimePattern).format(lastCal.getTime());
    }

    public static String getPrevMonthFirstDay() {
        //获取前月的第一天
        Calendar firstCal = Calendar.getInstance();//获取当前日期 
        firstCal.add(Calendar.MONTH, -1);
        firstCal.set(Calendar.DAY_OF_MONTH,1);     //设置为1号,当前日期既为本月第一天 
        
        firstCal.set(Calendar.SECOND, 0);          // 秒清零
        firstCal.set(Calendar.MINUTE, 0);          // 分清零
        firstCal.set(Calendar.HOUR_OF_DAY, 0);     // 时清零
        return DateUtil.getSdf(datetimePattern).format(firstCal.getTime());
    }
    
    public static int getDaysBetween(Date smdate, Date bgdate) throws ParseException {
    	if(null == smdate || null == bgdate) {
    		return -1;
    	}
    	// 获取两个日期之间的天数
    	SimpleDateFormat sdf = DateUtil.getSdf(datePattern);
    	smdate = sdf.parse(sdf.format(smdate));
    	bgdate = sdf.parse(sdf.format(bgdate));
        Calendar cal = Calendar.getInstance();
        cal.setTime(smdate);
        long time1 = cal.getTimeInMillis();
        cal.setTime(bgdate);
        long time2 = cal.getTimeInMillis();
        long between_days = (time2 - time1) / (1000 * 3600 * 24);
        // 返回
        return Integer.parseInt(String.valueOf(between_days));
    }  
    
    public static int getDaysBetween(String smdate,String bgdate) throws ParseException {
    	if(null == smdate || null == bgdate
    			|| "".equals(smdate) || "".equals(bgdate)) {
    		return -1;
    	}
    	// 获取两个日期之间的天数
    	SimpleDateFormat sdf = DateUtil.getSdf(datePattern);
        Calendar cal = Calendar.getInstance();
        cal.setTime(sdf.parse(smdate));
        long time1 = cal.getTimeInMillis();
        cal.setTime(sdf.parse(bgdate));
        long time2 = cal.getTimeInMillis();
        long between_days = (time2 - time1) / (1000 * 3600 * 24);
        // 返回
        return Integer.parseInt(String.valueOf(between_days));
    }

    
}
