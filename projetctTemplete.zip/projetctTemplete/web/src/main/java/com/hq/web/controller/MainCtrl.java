/** 
 * @Title:TODO  
 * @Desription:TODO
 * @Company:CSN
 * @ClassName:MainCtrl.java
 * @Author:justic
 * @CreateDate:2015-8-18   
 * @UpdateUser:justic  
 * @Version:0.1 
 *    
 */ 

package com.hq.web.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.hq.common.entity.User;
import com.hq.common.user.IUserService;

/** 
 * @ClassName: MainCtrl 
 * @Description: TODO 
 * @author: zhq 
 * @date: 2015-8-18
 * 
 */
@Controller
public class MainCtrl {

	@RequestMapping(value="/main",method=RequestMethod.GET)
	public ModelAndView openMain(HttpServletRequest request){
		
		ModelAndView mv=new ModelAndView("main");
		//用户中文名
		//mv.addObject("userName", UserUtil.getName());
		User userDto = (User)request.getSession().getAttribute(IUserService.SESSION_USERINFO);
		if(userDto !=null){
			mv.addObject("userName",userDto.getName());
			request.getSession().setAttribute("userName",userDto.getName());
		}
		
		return mv;
	}
	
	
	
}
