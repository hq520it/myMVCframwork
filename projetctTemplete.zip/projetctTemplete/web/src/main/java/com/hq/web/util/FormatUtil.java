package com.hq.web.util;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

public class FormatUtil {

	private static NumberFormat nFormat = NumberFormat.getNumberInstance();
	private static DecimalFormat numberFormat = new DecimalFormat("#.00");
	private static DecimalFormat numberFormat2 = new DecimalFormat("0000");
	
	// 采用本地线程池的方式解决多线程环境下 日期时间格式化类 出现的问题
	private static ThreadLocal<DateFormat> threadLocal = new ThreadLocal<DateFormat>() {
		@Override
		protected DateFormat initialValue() {
			return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		};
	};
	
	public static String getFormatedDatetime(Date date) {
		return threadLocal.get().format(null == date ? new Date() : date);
	}

	public static String getFormatedDatetime(Long timestamp) {
        return threadLocal.get().format(null == timestamp ? new Date() : timestamp);
    }
	
	public static Double getFormatedNumberVal(Double num) {
		num = null == num ? 0 : num;
		nFormat.setMaximumFractionDigits(2);					// 小数点后两位保留
		return Double.valueOf(nFormat.format(num));				// 标准化四舍五入,不能完全保证小数点后始终两位
	}
	
	public static Double getFormatedNumberVal2(Double num) {
		num = null == num ? 0 : num;
		return Double.valueOf(numberFormat.format(num));		// 标准化小数点后始终两位,同时四舍五入
	}
	
	public static String getFormatedNumberStr(Double num) {
		num = null == num ? 0 : num;
		nFormat.setMaximumFractionDigits(2);					// 小数点后两位保留
		double tmp = Double.parseDouble(nFormat.format(num));	// 四舍五入
		return numberFormat.format(tmp);						// 标准化小数点后始终两位，同时保留千位符
	}
	
	public static String getFormatedNumberStr2(Double num) {
		num = null == num ? 0 : num;
		return numberFormat.format(num);						// 标准化小数点后始终两位,同时四舍五入
	}

	public static String getFormatedSuffixId(int digits) {
		return numberFormat2.format(new Random().nextInt((int) Math.pow(10, digits < 0 ? 0 : digits)));
	}

}
