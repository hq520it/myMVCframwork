package com.hq.web.controller;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hq.service.test.ITestService;

@Controller

@RequestMapping("test")
public class TestController {

	@Autowired
	ITestService testService;
	
	@RequiresPermissions("admin")//shiro的权限
	@RequestMapping("hello")
	@ResponseBody
	public String testHello(){
		testService.testHello();
		return "ok";
	}
}
