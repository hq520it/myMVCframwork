package com.hq.common.user;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.hq.common.entity.Role;
import com.hq.common.entity.User;


public interface IUserService {

	public static final String SESSION_USERINFO = "userinfo";

	public void sayHello(String str);

	public Set<String> getPermissions(String string, String string2);

	public User getUserDto(String name,String password);

	public List<Map<String, Object>> getUserList();

	public User findByName(String loginName);

	public Set<String> getRolesName(User user);
	
	public List<Role> getRoleList(User user);

	public List<String> getPermissionsName(Integer id);

}
