package com.hq.common.dao;

import java.util.List;
import java.util.Map;

import com.hq.common.entity.User;

public interface UserMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(User record);

    int insertSelective(User record);

    User selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(User record);

    int updateByPrimaryKey(User record);

	List<Map<String, Object>> selectAll();

	User selectByEntity(Map<String, String> params);
	
	User selectByName(String name);
}