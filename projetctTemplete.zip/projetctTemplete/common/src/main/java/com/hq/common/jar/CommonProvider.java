package com.hq.common.jar;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CommonProvider implements Runnable{

	@Override
	public void run() {
		@SuppressWarnings("resource")
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
				new String[] { "spring/common-applicationContext.xml" });
		context.start();
	}

	public static void main(String[] args) throws Exception {
		CommonProvider p = new CommonProvider();
		Thread t1 = new Thread(p);
		t1.start();
		// 为保证服务一直开着
		while (true) {
			Thread.sleep(3600000);
		}
	}

}
