package com.hq.common.user.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hq.common.dao.PermissionMapper;
import com.hq.common.dao.RoleMapper;
import com.hq.common.dao.UserMapper;
import com.hq.common.entity.Permission;
import com.hq.common.entity.Role;
import com.hq.common.entity.User;
import com.hq.common.user.IUserService;

@Service("userService")
public class UserService implements IUserService{

	@Autowired  
    private UserMapper userMapper;  
	
	@Autowired
	private RoleMapper roleMapper;
	
	@Autowired
	private PermissionMapper permiMapper;
	
	@Override
	public void sayHello(String str) {
		// TODO Auto-generated method stub
		System.out.println("hello:"+str);
	}

	@Override
	public Set<String> getPermissions(String string, String string2) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public User getUserDto(String name, String password) {
		Map<String, String> params=new HashMap<String,String>();
		params.put("name", name);
		params.put("password", password);
		User userEntity=userMapper.selectByEntity(params);
		User userDto=new User();
		BeanUtils.copyProperties(userEntity, userDto);
		return userDto;
	}

	@Override
	public List<Map<String, Object>> getUserList() {
		
		return userMapper.selectAll();
	}

	@Override
	public User findByName(String loginName) {
		return userMapper.selectByName(loginName);
	}

	@Override
	public Set<String> getRolesName(User user) {
		Set<String> resSet=new HashSet<String>();
		List<Role> roleList=roleMapper.getRolesById(user);
		for (Role role : roleList) {
			resSet.add(role.getName());
		}
		return resSet;
	}

	@Override
	public List<Role> getRoleList(User user) {
		List<Role> roleList=roleMapper.getRolesById(user);
		return roleList;
	}

	@Override
	public List<String> getPermissionsName(Integer id) {
		List<Permission> permissions=permiMapper.selectByRoleId(id);
		List<String> permissionNameList=new ArrayList<String>();
		for (Permission permission : permissions) {
			permissionNameList.add(permission.getName());
		}
		return permissionNameList;
	}

	
}
