package common;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.hq.common.dao.PermissionMapper;
import com.hq.common.dao.RoleMapper;
import com.hq.common.dao.UserMapper;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:spring/common-applicationContext.xml")
public class UserTest {

	@Autowired
	UserMapper mapper;
	
	@Autowired
	private RoleMapper roleMapper;
	
	@Autowired
	private PermissionMapper permiMapper;
	
	@Test
	public void testselectAll(){
		System.out.println(mapper.selectByPrimaryKey(1));
		System.out.println("结果："+permiMapper.selectByRoleId(1));
		System.out.println("结果："+roleMapper.getRolesById(mapper.selectByName("test")));
		System.out.println(mapper.selectAll());
		System.out.println(mapper.selectAll());

	}
}
